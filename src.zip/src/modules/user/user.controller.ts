import { Controller, Post, Body, Put, Param, Get, Delete, UseGuards, Query } from '@nestjs/common';
import { UserService } from './user.service';
import { CreateUserDto } from './dto/create-user.dto';
import { UpdateUserDto } from './dto/update-user.dto';
import { Roles } from '../../common/decorators/roles.decorator';
import { UserRole } from '../../common/enums/role.enum';
import { AuthGuard } from '../auth/guards/auth.guard';
import { PaginationDto } from 'src/common/dtos/pagination.dto';
import { ApiConsumes, ApiTags } from '@nestjs/swagger';
import { SwaggerConsumes } from 'src/common/enums/swager-consumes.enum';
import { AuthDecorator } from 'src/common/decorators/auth.decorator';

@Controller('users')
@ApiTags('Users')
export class UserController {
  constructor(private readonly userService: UserService) {}

  @Get()
  @Roles(UserRole.ADMIN)
  @UseGuards(AuthGuard)
  @AuthDecorator()
  async getAllUsers(@Query() paginationDto: PaginationDto) {
    return this.userService.findAll(paginationDto);
  }

  @Get(':id')
  @AuthDecorator()
  @UseGuards(AuthGuard)
  async getUserById(@Param('id') id: string) {
    return this.userService.getUserById(id);
  }

  @Delete(':id')
  @Roles(UserRole.ADMIN)
  @UseGuards(AuthGuard)
  @AuthDecorator()
  async deleteUser(@Param('id') id: string) {
    return this.userService.deleteUser(id);
  }
}