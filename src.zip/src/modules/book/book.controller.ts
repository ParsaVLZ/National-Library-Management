import { Controller, Post, Body, Put, Param, Get, Delete, UseGuards, Query, Req } from '@nestjs/common';
import { BookService } from './book.service';
import { CreateBookDto } from './dto/create-book.dto';
import { UpdateBookDto } from './dto/update-book.dto';
import { PaginationDto } from '../../common/dtos/pagination.dto';
import { Roles } from '../../common/decorators/roles.decorator';
import { UserRole } from '../../common/enums/role.enum';
import { AuthGuard } from '../auth/guards/auth.guard';
import { ApiConsumes, ApiOperation, ApiResponse, ApiTags } from '@nestjs/swagger';
import { Request } from 'express';
import { SwaggerConsumes } from 'src/common/enums/swager-consumes.enum';
import { RoleGuard } from '../auth/guards/role.guard';

@ApiTags('Books')
@Controller('books')
export class BookController {
  constructor(private readonly bookService: BookService) {}

  @Post()
  @Roles(UserRole.LIBRARY_OWNER)
  @ApiConsumes(SwaggerConsumes.UrlEncoded, SwaggerConsumes.Json)
  @UseGuards(AuthGuard, RoleGuard)
  @ApiOperation({ summary: 'Create a new book' })
  @ApiResponse({ status: 201, description: 'Book created successfully' })
  @ApiResponse({ status: 400, description: 'Invalid input' })
  async createBook(@Body() createBookDto: CreateBookDto, @Req() req: Request) {
    return this.bookService.create(createBookDto, req.user);
  }

  @Put(':id')
  @Roles(UserRole.LIBRARY_OWNER)
  @UseGuards(AuthGuard, RoleGuard)
  @ApiOperation({ summary: 'Update book information' })
  @ApiResponse({ status: 200, description: 'Book updated successfully' })
  @ApiResponse({ status: 404, description: 'Book not found' })
  async updateBook(@Param('id') id: string, @Body() updateBookDto: UpdateBookDto, @Req() req: Request) {
    return this.bookService.update(id, updateBookDto, req.user);
  }

  @Get()
  @ApiOperation({ summary: 'Get all books with pagination' })
  @ApiResponse({ status: 200, description: 'Books retrieved successfully' })
  async getAllBooks(@Query() paginationDto: PaginationDto) {
    return this.bookService.findAll(paginationDto);
  }

  @Get(':id')
  @ApiOperation({ summary: 'Get book by ID' })
  @ApiResponse({ status: 200, description: 'Book retrieved successfully' })
  @ApiResponse({ status: 404, description: 'Book not found' })
  async getBookById(@Param('id') id: string) {
    return this.bookService.findOne(id);
  }

  @Delete(':id')
  @Roles(UserRole.LIBRARY_OWNER)
  @UseGuards(AuthGuard)
  @ApiOperation({ summary: 'Delete book by ID' })
  @ApiResponse({ status: 200, description: 'Book deleted successfully' })
  @ApiResponse({ status: 404, description: 'Book not found' })
  async deleteBook(@Param('id') id: string, @Req() req: Request) {
    return this.bookService.delete(id, req.user);
  }
}
