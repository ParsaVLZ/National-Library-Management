import { ApiProperty } from '@nestjs/swagger';
import { IsString, IsInt, IsNotEmpty, IsOptional } from 'class-validator';

export class CreateBookDto {
  @ApiProperty()
  @IsString()
  @IsNotEmpty()
  title: string;
  @ApiProperty()
  @IsString()
  @IsNotEmpty()
  author: string;
  @ApiProperty()
  @IsInt()
  @IsNotEmpty()
  price: number;
  @ApiProperty()
  @IsInt()
  @IsNotEmpty()
  quantity: number;
  @ApiProperty()
  @IsString()
  @IsOptional()
  description?: string;
}
