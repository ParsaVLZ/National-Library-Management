export type CookiePayload = {
    userId: string;
  };
  
export type AccessTokenPayload = {
    userId: string;
};
  