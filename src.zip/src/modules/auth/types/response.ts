export type AuthResponse = {
    code: string;
    token: string;
  };
  