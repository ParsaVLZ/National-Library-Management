export enum UserRole {
    ADMIN = 'Admin',
    USER = 'User',
    LIBRARY_OWNER = 'Library_Owner'
  }