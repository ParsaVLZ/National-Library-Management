export enum EntityName {
    USER = 'users',
    OTP = 'otp',
    LIBRARY = 'libraries',
    BOOK = 'books',
    ORDER = 'orders'
  }